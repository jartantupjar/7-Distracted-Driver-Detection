Dataset:
Kaggle link: https://www.kaggle.com/c/state-farm-distracted-driver-detection/data
File names: driver_imgs_list.csv
	    imgs.zip
	    sample_submission.csv