HELLO FELLOW HUMAN!!!

Dataset:
Kaggle link: https://www.kaggle.com/c/state-farm-distracted-driver-detection/data
File names: driver_imgs_list.csv
	    imgs.zip
	    sample_submission.csv

Proposal review link: https://review.udacity.com/#!/reviews/827153

Instructions:
Option 1:
	1. Read this
	2. Download files
	3. Extract imgs.zip in the 'Data' folder
	4. Place driver_imgs_list.csv in the Data folder
	5. Open solution 3 python notebook
	6. Execute files
	7. Submit the results in the Kaggle competition
	8. View score(I left you the option to submit the individual model 		predictions and the combined one) 

Option 2: SHORTCUT!!!	
	1. Read this
	2. Go to submissions folder
	3. Submit results in the Kaggle competition
	4. View score(I left you the option to submit the individual model 		predictions and the combined one for better comparison)

Libraries
	No external download libraries has been used. I simply used Jupyter Notebook with Anaconda3 (Python 3) and I used Keras(latest version) 

Troubleshooting:
	1. Ran out of memory? 
		Solution: Buy more RAM
	2. Are some visualizations not working?
		Solution: open cmd/anaconda prompt then input this line : 	jupyter notebook --NotebookApp.iopub_data_rate_limit=100000000
	3. Why did I take so long -(3 months)
		my experience... my hardware...
	4. Why does the solution suck?
		Im sorry i tried so hard...
	5. Why is this the solution the best thing I have ever seen?
		Awww stop flattering me ~~~
		What I did was the product of pain, patience and money well spent?~

			
